
import edu.br.unicarioca.DAO.Aluno;
import edu.br.unicarioca.DAO.JDBCAlunoDAO;
import java.sql.SQLException;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author podgorski
 */
public class testando {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        // TODO code application logic here
        //Executa a busca pelo nome
        JDBCAlunoDAO aDao = new JDBCAlunoDAO();
        
        Aluno novoAluno = new Aluno();
        novoAluno.setNome("Marcos");
        novoAluno.setId(1);
        novoAluno.setCpf("123123123");
        aDao.inserir(novoAluno);
//        
//        
//        JDBCAlunoDAO bDao = new JDBCAlunoDAO();
//        List<Aluno> alunosLetra = bDao.listarNome("p");
//
//        
//        for (Aluno lista : alunosLetra) {
//            
//            System.out.println(lista.getNome());
//        } 
//        
//        
//        Aluno alunoAlterado = new Aluno();
//        alunoAlterado.setId(1);
//        alunoAlterado.setNome("Antonio Podgorski");
//        alunoAlterado.setCpf("999999999");
//        
//        JDBCAlunoDAO dDao = new JDBCAlunoDAO();
//        dDao.alterar(alunoAlterado);
        
        
        Aluno alunoExclusao = new Aluno();
        alunoExclusao.setId(4);
        JDBCAlunoDAO eDao = new JDBCAlunoDAO();
        eDao.remover(alunoExclusao);
        
        
        JDBCAlunoDAO cDao = new JDBCAlunoDAO();
        List<Aluno> alunos = cDao.listar();


        for (Aluno lista : alunos) {
            System.out.println(lista.getNome());
        } 
        
        
        
        
    }
}
